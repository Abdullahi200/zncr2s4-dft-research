pw<ZnCrS1.in>ZnCrS1_Relax.out
pw<ZnCrS2.in>ZnCrS2_Relax.out
pw<ZnCrS3.in>ZnCrS3_Relax.out
pw<ZnCrS4.in>ZnCrS4_Relax.out
pw<ZnCrS5.in>ZnCrS5_Relax.out
pw<ZnCrS6.in>ZnCrS6_Relax.out
pw<ZnCrS7.in>ZnCrS7_Relax.out